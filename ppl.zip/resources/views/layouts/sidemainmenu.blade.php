<div class="sidenav-menu">
  <div class="sidenav-head">
    <span class="title">LOGO</span>
    <button class="button button-close-sidenav"></button>
  </div>
  <div class="sidenav-body">
    <div class="sidenav-body-inner">
      <ul class="menu">
        <li class="el-megamenu el-megamenu-xs">
          <a href="#">
            <span class="text">Home</span>
          </a>
        </li>
        <li class="el-megamenu el-megamenu-lg">
          <a href="#">
            <span class="text">Fruits</span>
          </a>
        </li>
        <li class="el-megamenu el-megamenu-lg">
          <a href="#">
            <span class="text">Shop</span>
          </a>
        </li>
        <li>
          <a href="page-about.html">
            <span class="text">About Us</span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</div>