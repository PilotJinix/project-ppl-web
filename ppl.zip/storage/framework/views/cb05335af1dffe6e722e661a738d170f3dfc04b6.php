<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mb-3">
                <ul class="breadcrumb breadcrumb-style ">
                    <li class="breadcrumb-item">
                        <h4 class="page-title border-right-0">Tambah Produk Baru</h4>
                    </li>

                    <li class="breadcrumb-item bcrumb-1">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="breadcrumb-item bcrumb-2">
                        <a href="#" onClick="return false;">E-commerce</a>
                    </li>
                    <li class="breadcrumb-item active">Produk Baru</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="body">
                    <form action="<?php echo e(route('admin.save-harga')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group form-float">
                            <div class="form-line mb-4">
                                <input type="text" class="form-control <?php if ($errors->has('nama_produk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_produk'); ?> not valid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    name="nama_produk" style="font-size: 20px">
                                <label class="form-label">Nama Produk</label>
                            </div>
                            <?php if ($errors->has('nama_produk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_produk'); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <div class="form-line mb-4">
                                <h3 class="card-inside-title mb-0">Kategori</h3>
                                <select class="form-control <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?> not valid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="kategori">
                                    <option disabled selected>Pilih Kategori
                                    </option>
                                    <option>Buah</option>
                                    <option>Sayuran</option>
                                </select>
                            </div>
                            <?php if ($errors->has('kategori')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('kategori'); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <div class="form-group">
                                <h3 class="card-inside-title">Harga / Kg</h3>
                                <input class="form-control <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> not valid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="harga"
                                    type="number" placeholder="Masukkan Harga Produk" min="1">
                            </div>
                            <?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger pt-2">Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/witsudi/LaravelProject/project-ppl/resources/views/admin/newharga.blade.php ENDPATH**/ ?>