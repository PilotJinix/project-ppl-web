<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mb-3">
                <ul class="breadcrumb breadcrumb-style ">
                    <li class="breadcrumb-item">
                        <h4 class="page-title border-right-0">Tambah Produk Baru</h4>
                    </li>

                    <li class="breadcrumb-item bcrumb-1">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="breadcrumb-item bcrumb-2">
                        <a href="#" onClick="return false;">E-commerce</a>
                    </li>
                    <li class="breadcrumb-item active">Produk Baru</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="body">
                    <form action="<?php echo e(route('admin.save-artikel')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group form-float">
                            <div class="form-line mb-4">
                                <h3 class="card-inside-title mb-0">Judul Artikel</h3>
                                <input type="text" class="form-control <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?> not valid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="judul"
                                    style="font-size: 20px">
                            </div>
                            <?php if ($errors->has('judul')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('judul'); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <div class="file-field input-field mb-4">
                                <h3 class="card-inside-title">Unggah Gambar Artikel</h3>
                                <div class="file-field input-field">
                                    <div class="btn">
                                        <span>Browse</span>
                                        <input type="file" class="<?php if ($errors->has('foto_produk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto_produk'); ?> not valid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                            name="gambar_artikel">
                                    </div>
                                    <div class="file-path-wrapper">
                                        <input class="file-path validate " type="text" placeholder="Unggah Gambar">
                                    </div>
                                </div>
                            </div>
                            <?php if ($errors->has('foto_produk')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto_produk'); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <div class="form-group">
                                <h3 class="card-inside-title">Deskripsi Produk</h3>
                                <div class="form-line">
                                    <textarea id="text-area" rows="4"
                                        class="form-control no-resize <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?> not valid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                        name="deskripsi"></textarea>
                                </div>
                            </div>
                            <?php if ($errors->has('deskripsi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('deskripsi'); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <button class="btn btn-primary" type="submit">Simpan</button>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger pt-2">Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/ckeditor/ckeditor.js')); ?>"></script>
    <script>
        const area = document.getElementById('text-area');
        CKEDITOR.replace(area);

    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/witsudi/LaravelProject/project-ppl/resources/views/admin/newartikel.blade.php ENDPATH**/ ?>