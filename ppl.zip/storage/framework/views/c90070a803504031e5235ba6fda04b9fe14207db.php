<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <ul class="breadcrumb breadcrumb-style ">
                    <li class="breadcrumb-item">
                        <h4 class="page-title">Riwayat Transaksi</h4>
                    </li>
                    <li class="breadcrumb-item bcrumb-1">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="breadcrumb-item bcrumb-2">
                        <a href="#" onClick="return false;">Riwayat Transaksi</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- #START# Table With State Save -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                </div>
                <div id="table-semua">
                    <div class="body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover save-stage dataTable"
                                style="width:100%;">
                                <thead>
                                    <tr>
                                        <th>Nama Lengkap</th>
                                        <th>Email</th>
                                        <th>Alamat</th>
                                        <th>Status</th>
                                        <th>Nomer HP</th>
                                        <th>Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($list->status_checkout == 'Dibatalkan'): ?>
                                    <?php else: ?>
                                    <tr>
                                        <td><?php echo e(__($list->nama_penerima)); ?></td>
                                        <td><?php echo e(__('+62'.$list->no_hp_penerima)); ?></td>
                                        <td><?php echo e(__($list->alamat_penerima)); ?></td>
                                        <td><?php echo e(__($list->status_checkout)); ?></td>
                                        <td><?php echo e(__($list->metode_pembayaran)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.invoice',$list->id)); ?>">
                                                <button class="btn tblActnBtn" data-toggle="tooltip"
                                                    title="Detail Chekout">
                                                    <i class="material-icons">remove_red_eye</i>
                                                </button>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/witsudi/LaravelProject/project-ppl/resources/views/admin/riwayattransaksi.blade.php ENDPATH**/ ?>