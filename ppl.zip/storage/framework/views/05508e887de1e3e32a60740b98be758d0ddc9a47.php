<?php echo e($slot); ?>

<?php /**PATH /home/witsudi/LaravelProject/project-ppl/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>